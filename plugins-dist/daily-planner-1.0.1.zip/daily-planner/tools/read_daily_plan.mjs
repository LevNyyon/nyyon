// Daily Planner plugin — read_daily_plan. Ported verbatim from the host module;
// every host import replaced by the capability object (api.db is scoped to the
// plugin_daily_planner_* tables, api.knowledge to the declared read set).

export const def = {
  name: 'read_daily_plan',
  description: "Read one day's plan (schedule blocks + to-dos). date is YYYY-MM-DD, default today. Call this before editing a day or to see what is already planned.",
  input_schema: { type: 'object', properties: { date: { type: 'string', description: 'YYYY-MM-DD; default today' } }, required: [] },
};

// kpi-outreach is the host note holding the operator timezone + workweek —
// declared in requires.knowledge so the read is visible at import time.
const KPI_DEFAULTS = { tz: 'UTC', work_days: [0, 1, 2, 3, 4] };
// Smaller models (and any model under pressure) routinely pass an array
// parameter as a JSON STRING. Treating that as "not an array" saved an EMPTY
// plan and reported success, which is worse than an error: the operator sees
// a blank day and no reason. Parse the string, then carry on.
function asArray(v) {
  if (Array.isArray(v)) return v;
  if (typeof v === 'string') {
    const t = v.trim();
    if (!t) return [];
    try { const p = JSON.parse(t); return Array.isArray(p) ? p : [p]; } catch { return []; }
  }
  if (v && typeof v === 'object') return [v];
  return [];
}
async function kpiCfg(api) {
  try {
    const doc = await api.knowledge('kpi-outreach');
    const m = String(doc?.body || '').match(/```json\s*([\s\S]*?)```/);
    const cfg = m ? JSON.parse(m[1]) : null;
    return cfg && typeof cfg === 'object' ? { ...KPI_DEFAULTS, ...cfg } : KPI_DEFAULTS;
  } catch { return KPI_DEFAULTS; }
}
async function todayLocal(api) {
  const cfg = await kpiCfg(api);
  try { return new Date().toLocaleDateString('en-CA', { timeZone: cfg.tz || 'UTC' }); }
  catch { return new Date().toISOString().slice(0, 10); }
}
function normalizePlanBody(plan = {}) {
  const schedule = asArray(plan.schedule).map((b, i) => ({
    id: b.id || `b${i + 1}`,
    start: b.start ? String(b.start).slice(0, 10) : null,
    end: b.end ? String(b.end).slice(0, 10) : null,
    title: String(b.title || '').slice(0, 400),
    deliverable: b.deliverable ? String(b.deliverable).slice(0, 400) : null,
    done: !!b.done,
    focus: !!b.focus,
  }));
  const todos = asArray(plan.todos).map((tk, i) => ({
    id: tk.id || `t${i + 1}`,
    text: String(tk.text || '').slice(0, 400),
    done: !!tk.done,
    star: !!tk.star,
    priority: Number.isFinite(tk.priority) ? tk.priority : i + 1,
  }));
  return {
    summary: String(plan.summary || '').slice(0, 1000),
    weekly_ref: plan.weekly_ref ? String(plan.weekly_ref).slice(0, 10) : null,
    schedule,
    todos,
  };
}
function rowToPlan(row) {
  if (!row) return null;
  let body = {};
  try { body = JSON.parse(row.plan || '{}'); } catch { body = {}; }
  const norm = normalizePlanBody(body);
  return {
    date: row.date, mode: row.mode || body.mode || 'wing_it',
    summary: norm.summary, weekly_ref: norm.weekly_ref,
    schedule: norm.schedule, todos: norm.todos,
    created_at: row.created_at, updated_at: row.updated_at,
  };
}
async function readPlan(api, date) {
  const row = await api.db
    .prepare('SELECT date, plan, mode, created_at, updated_at FROM plugin_daily_planner_plans WHERE date = ?')
    .bind(date).first();
  return rowToPlan(row);
}

export async function run(api, input) {
  const date = input?.date || (await todayLocal(api));
  const plan = await readPlan(api, date);
  return plan ? { date, plan } : { date, plan: null, note: 'no plan yet for this day' };
}
